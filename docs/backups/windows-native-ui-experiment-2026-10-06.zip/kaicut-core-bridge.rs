#[path = "../project.rs"]
mod project;

use project::{KaicutProject, ProjectSession, import_media, read_project, save_project, timestamp, validate_text};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::{
    io::{self, BufRead, Write},
    path::PathBuf,
};

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct Request {
    id: u64,
    command: String,
    #[serde(default)]
    args: Value,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct Response {
    id: u64,
    ok: bool,
    session: Option<ProjectSession>,
    error: Option<String>,
}

fn string_arg(args: &Value, name: &str) -> Result<String, String> {
    args.get(name)
        .and_then(Value::as_str)
        .map(str::to_owned)
        .ok_or_else(|| format!("缺少参数：{name}"))
}

fn bool_arg(args: &Value, name: &str) -> bool {
    args.get(name).and_then(Value::as_bool).unwrap_or(false)
}

fn run_command(session: &mut ProjectSession, command: &str, args: &Value) -> Result<(), String> {
    match command {
        "get" => Ok(()),
        "new" => {
            if session.dirty && !bool_arg(args, "discard") {
                return Err("当前项目有未保存的更改，需要确认后再新建".into());
            }
            *session = ProjectSession::default();
            session.status = "已新建项目".into();
            Ok(())
        }
        "open" => {
            if session.dirty && !bool_arg(args, "discard") {
                return Err("当前项目有未保存的更改，需要确认后再打开".into());
            }
            let path = PathBuf::from(string_arg(args, "path")?);
            let project = read_project(&path)?;
            let path = path
                .to_str()
                .ok_or("项目路径必须是有效 Unicode")?
                .to_string();
            *session = ProjectSession {
                status: format!("已打开 {}", project.name),
                project,
                path: Some(path),
                dirty: false,
            };
            Ok(())
        }
        "save" => {
            let path = if let Some(path) = &session.path {
                PathBuf::from(path)
            } else {
                PathBuf::from(string_arg(args, "path")?)
            };
            let mut snapshot: KaicutProject = session.project.clone();
            snapshot.updated_at = timestamp();
            save_project(&path, &snapshot)?;
            let path = path
                .to_str()
                .ok_or("项目路径必须是有效 Unicode")?
                .to_string();
            session.project = snapshot;
            session.path = Some(path);
            session.dirty = false;
            session.status = "项目已保存".into();
            Ok(())
        }
        "rename" => {
            let name = string_arg(args, "name")?;
            let name = name.trim();
            validate_text(name, "项目名称", 120)?;
            if session.project.name != name {
                session.project.name = name.to_owned();
                session.project.updated_at = timestamp();
                session.dirty = true;
                session.status = "项目名称已更新，尚未保存".into();
            }
            Ok(())
        }
        "import" => {
            let paths = args
                .get("paths")
                .and_then(Value::as_array)
                .ok_or("缺少参数：paths")?
                .iter()
                .map(|path| path.as_str().map(PathBuf::from).ok_or("素材路径无效"))
                .collect::<Result<Vec<_>, _>>()?;
            let (added, skipped) = import_media(&mut session.project, paths)?;
            if added > 0 {
                session.dirty = true;
            }
            session.status = if skipped > 0 {
                format!("已导入 {added} 项素材，跳过 {skipped} 项重复或不支持的文件")
            } else {
                format!("已导入 {added} 项素材")
            };
            Ok(())
        }
        _ => Err(format!("不支持的原生项目命令：{command}")),
    }
}

fn respond(id: u64, session: &mut ProjectSession, command: &str, args: &Value) -> Response {
    match run_command(session, command, args) {
        Ok(()) => Response {
            id,
            ok: true,
            session: Some(session.clone()),
            error: None,
        },
        Err(error) => Response {
            id,
            ok: false,
            session: Some(session.clone()),
            error: Some(error),
        },
    }
}

fn main() {
    let stdin = io::stdin();
    let mut stdout = io::BufWriter::new(io::stdout().lock());
    let mut session = ProjectSession::default();

    for line in stdin.lock().lines() {
        let response = match line {
            Ok(line) => match serde_json::from_str::<Request>(&line) {
                Ok(request) => respond(request.id, &mut session, &request.command, &request.args),
                Err(error) => Response {
                    id: 0,
                    ok: false,
                    session: Some(session.clone()),
                    error: Some(format!("原生项目请求无效：{error}")),
                },
            },
            Err(error) => {
                eprintln!("读取原生项目请求失败：{error}");
                break;
            }
        };

        if serde_json::to_writer(&mut stdout, &response).is_err()
            || writeln!(stdout).is_err()
            || stdout.flush().is_err()
        {
            break;
        }
    }
}
