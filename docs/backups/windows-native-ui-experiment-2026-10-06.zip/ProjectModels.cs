namespace KaiCut.Windows.Models;

public sealed class NativeProjectSession
{
    public KaicutProject Project { get; set; } = new();
    public string? Path { get; set; }
    public bool Dirty { get; set; }
    public string Status { get; set; } = string.Empty;
}

public sealed class KaicutProject
{
    public uint SchemaVersion { get; set; }
    public string AppVersion { get; set; } = string.Empty;
    public string ProjectId { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string CreatedAt { get; set; } = string.Empty;
    public string UpdatedAt { get; set; } = string.Empty;
    public Timebase Timebase { get; set; } = new();
    public List<MediaAsset> MediaRefs { get; set; } = [];
    public List<TimelineTrack> Tracks { get; set; } = [];
}

public sealed class Timebase
{
    public uint FpsNumerator { get; set; }
    public uint FpsDenominator { get; set; }
}

public sealed class MediaAsset
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Kind { get; set; } = string.Empty;
    public string Extension { get; set; } = string.Empty;
    public ulong Size { get; set; }
    public ulong LastModified { get; set; }
    public string? SourcePath { get; set; }
}

public sealed class TimelineTrack
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Kind { get; set; } = string.Empty;
    public bool Locked { get; set; }
    public bool Muted { get; set; }
    public List<TimelineClip> Clips { get; set; } = [];
}

public sealed class TimelineClip
{
    public string Id { get; set; } = string.Empty;
    public string MediaId { get; set; } = string.Empty;
    public string TrackId { get; set; } = string.Empty;
    public ulong StartFrame { get; set; }
    public ulong DurationFrames { get; set; }
}
