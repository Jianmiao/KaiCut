using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using KaiCut.Windows.Models;
using KaiCut.Windows.Services;
using Microsoft.Win32;

namespace KaiCut.Windows;

public partial class MainWindow : Window
{
    private readonly ObservableCollection<MediaItem> _media = [];
    private readonly CollectionView _mediaView;
    private RustProjectClient? _projectClient;
    private NativeProjectSession? _session;
    private bool _initializing;

    public MainWindow()
    {
        InitializeComponent();
        _mediaView = (CollectionView)CollectionViewSource.GetDefaultView(_media);
        _mediaView.Filter = FilterMedia;
        DataContext = this;
        MediaList.ItemsSource = _mediaView;
        TrackList.ItemsSource = new[]
        {
            new TrackRow("video-1", "视频 1", "▣", "video"),
            new TrackRow("video-2", "视频 2", "▣", "empty"),
            new TrackRow("audio-1", "音频 1", "♫", "audio"),
            new TrackRow("audio-2", "音频 2", "♫", "empty"),
        };
    }

    private async void Window_Loaded(object sender, RoutedEventArgs e)
    {
        _initializing = true;
        try
        {
            _projectClient = RustProjectClient.Start();
            ApplySession(await _projectClient.SendAsync("get"));
        }
        catch (Exception error)
        {
            StatusText.Text = $"Rust 项目服务启动失败：{error.Message}";
        }
        finally
        {
            _initializing = false;
        }
    }

    private async void NewProject_Click(object sender, RoutedEventArgs e)
    {
        if (!await ConfirmDiscardAsync()) return;
        await RunProjectCommandAsync("new", new { discard = true });
    }

    private async void OpenProject_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Title = "打开 KaiCut 项目",
            Filter = "KaiCut 项目 (*.kaicut)|*.kaicut",
            CheckFileExists = true,
            Multiselect = false,
        };
        if (dialog.ShowDialog(this) != true || !await ConfirmDiscardAsync()) return;
        await RunProjectCommandAsync("open", new { path = dialog.FileName, discard = true });
    }

    private async void SaveProject_Click(object sender, RoutedEventArgs e)
    {
        if (_projectClient?.Session is not { } current) return;
        string? path = current.Path;
        if (string.IsNullOrEmpty(path))
        {
            var dialog = new SaveFileDialog
            {
                Title = "保存 KaiCut 项目",
                Filter = "KaiCut 项目 (*.kaicut)|*.kaicut",
                DefaultExt = ".kaicut",
                AddExtension = true,
                FileName = $"{SafeFileName(current.Project.Name)}.kaicut",
                OverwritePrompt = true,
            };
            if (dialog.ShowDialog(this) != true) return;
            path = dialog.FileName;
        }
        await RunProjectCommandAsync("save", new { path });
    }

    private async void ImportMedia_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Title = "导入媒体",
            Filter = "视频、音频与图片|*.mp4;*.mov;*.mp3;*.wav;*.png;*.jpg;*.jpeg|所有文件|*.*",
            Multiselect = true,
            CheckFileExists = true,
        };
        if (dialog.ShowDialog(this) != true) return;
        await RunProjectCommandAsync("import", new { paths = dialog.FileNames });
    }

    private async Task RunProjectCommandAsync(string command, object args)
    {
        if (_projectClient is null)
        {
            StatusText.Text = "Rust 项目服务尚未就绪。";
            return;
        }
        try
        {
            ApplySession(await _projectClient.SendAsync(command, args));
        }
        catch (Exception error)
        {
            StatusText.Text = error.Message;
        }
    }

    private Task<bool> ConfirmDiscardAsync()
    {
        if (_session?.Dirty != true) return Task.FromResult(true);
        var result = MessageBox.Show(this,
            $"“{_session.Project.Name}”有未保存的更改。继续将丢弃这些更改。",
            "KaiCut · 未保存的更改", MessageBoxButton.YesNo, MessageBoxImage.Warning,
            MessageBoxResult.No);
        return Task.FromResult(result == MessageBoxResult.Yes);
    }

    private async void ProjectNameBox_LostFocus(object sender, RoutedEventArgs e)
    {
        if (_initializing || _session is null || ProjectNameBox.Text == _session.Project.Name) return;
        await RenameProjectAsync();
    }

    private async void ProjectNameBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter)
        {
            e.Handled = true;
            Keyboard.ClearFocus();
            await RenameProjectAsync();
        }
        else if (e.Key == Key.Escape && _session is not null)
        {
            ProjectNameBox.Text = _session.Project.Name;
            e.Handled = true;
        }
    }

    private async Task RenameProjectAsync()
    {
        if (_session is null || _projectClient is null) return;
        await RunProjectCommandAsync("rename", new { name = ProjectNameBox.Text });
        if (_session is not null) ProjectNameBox.Text = _session.Project.Name;
    }

    private void SearchBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        => _mediaView.Refresh();

    private bool FilterMedia(object item)
    {
        if (item is not MediaItem media) return false;
        return string.IsNullOrWhiteSpace(SearchBox?.Text)
            || media.Name.Contains(SearchBox.Text, StringComparison.CurrentCultureIgnoreCase);
    }

    private void MediaList_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        if (MediaList.SelectedItem is not MediaItem item)
        {
            InspectorEmptyState.Visibility = Visibility.Visible;
            InspectorDetails.Visibility = Visibility.Collapsed;
            return;
        }
        InspectorEmptyState.Visibility = Visibility.Collapsed;
        InspectorDetails.Visibility = Visibility.Visible;
        SelectedMediaName.Text = item.Name;
        SelectedMediaKind.Text = item.KindLabel;
        SelectedMediaPath.Text = item.SourcePath ?? "路径不可用";
    }

    private void ToggleInspector_Click(object sender, RoutedEventArgs e)
    {
        InspectorColumn.Width = InspectorColumn.Width.Value > 0
            ? new GridLength(0)
            : new GridLength(280);
    }

    private async void Window_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (Keyboard.Modifiers != ModifierKeys.Control || Keyboard.FocusedElement is System.Windows.Controls.TextBox) return;
        if (e.Key == Key.N)
        {
            e.Handled = true;
            if (await ConfirmDiscardAsync()) await RunProjectCommandAsync("new", new { discard = true });
        }
        else if (e.Key == Key.O) { e.Handled = true; OpenProject_Click(this, new RoutedEventArgs()); }
        else if (e.Key == Key.S) { e.Handled = true; SaveProject_Click(this, new RoutedEventArgs()); }
    }

    private void Window_Closing(object? sender, CancelEventArgs e)
    {
        if (_session?.Dirty != true) return;
        var result = MessageBox.Show(this,
            $"“{_session.Project.Name}”有未保存的更改。关闭将丢弃这些更改。",
            "KaiCut · 未保存的更改", MessageBoxButton.YesNo, MessageBoxImage.Warning,
            MessageBoxResult.No);
        e.Cancel = result != MessageBoxResult.Yes;
    }

    private async void Window_Closed(object? sender, EventArgs e)
    {
        if (_projectClient is not null) await _projectClient.DisposeAsync();
    }

    private void ApplySession(NativeProjectSession session)
    {
        _session = session;
        _initializing = true;
        ProjectNameBox.Text = session.Project.Name;
        SequenceTitle.Text = session.Project.Name;
        SaveStateText.Text = session.Dirty ? "未保存" : session.Path is null ? "新项目" : "已保存";
        StatusText.Text = session.Status;
        _media.Clear();
        foreach (var media in session.Project.MediaRefs) _media.Add(new MediaItem(media));
        MediaCountText.Text = _media.Count.ToString();
        MediaFooterText.Text = $"{_media.Count} 个项目";
        MediaEmptyState.Visibility = _media.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        TrackCountText.Text = $"{session.Project.Tracks.Count} 条轨道";
        _mediaView.Refresh();
        _initializing = false;
    }

    private static string SafeFileName(string name)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var cleaned = new string(name.Select(character => invalid.Contains(character) ? '_' : character).ToArray()).Trim();
        return string.IsNullOrEmpty(cleaned) ? "未命名项目" : cleaned;
    }

    public sealed class MediaItem
    {
        public MediaItem(MediaAsset media)
        {
            Name = media.Name;
            Kind = media.Kind;
            Extension = media.Extension.ToUpperInvariant();
            SizeLabel = media.Size < 1024 * 1024
                ? $"{Math.Max(1, media.Size / 1024)} KB"
                : $"{media.Size / (1024d * 1024d):F2} MB";
            SourcePath = media.SourcePath;
            KindLabel = media.Kind switch { "video" => "视频素材", "audio" => "音频素材", _ => "图片素材" };
        }

        public string Name { get; }
        public string Kind { get; }
        public string Extension { get; }
        public string SizeLabel { get; }
        public string? SourcePath { get; }
        public string KindLabel { get; }
    }

    public sealed class TrackRow(string id, string name, string icon, string specimen)
    {
        public string Id { get; } = id;
        public string Name { get; } = name;
        public string Icon { get; } = icon;
        public Visibility VideoSpecimenVisibility { get; } = specimen == "video" ? Visibility.Visible : Visibility.Collapsed;
        public Visibility AudioSpecimenVisibility { get; } = specimen == "audio" ? Visibility.Visible : Visibility.Collapsed;
        public Visibility EmptyLabelVisibility { get; } = specimen == "empty" ? Visibility.Visible : Visibility.Collapsed;
    }
}
