using System.Diagnostics;
using System.IO;
using System.Text.Json;
using KaiCut.Windows.Models;

namespace KaiCut.Windows.Services;

public sealed class RustProjectClient : IAsyncDisposable
{
    private readonly Process _process;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private long _requestId;

    private RustProjectClient(Process process) => _process = process;

    public NativeProjectSession? Session { get; private set; }

    public static RustProjectClient Start()
    {
        var executable = Path.Combine(AppContext.BaseDirectory, "kaicut-core-bridge.exe");
        if (!File.Exists(executable))
            throw new FileNotFoundException("KaiCut Rust 项目服务未找到。请运行 pnpm native:build。", executable);

        var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = executable,
                WorkingDirectory = AppContext.BaseDirectory,
                UseShellExecute = false,
                RedirectStandardInput = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
            },
            EnableRaisingEvents = true,
        };
        process.Start();
        return new RustProjectClient(process);
    }

    public async Task<NativeProjectSession> SendAsync(string command, object? args = null)
    {
        await _gate.WaitAsync();
        try
        {
            if (_process.HasExited)
                throw new InvalidOperationException("KaiCut 项目服务已退出。");

            var request = JsonSerializer.Serialize(new
            {
                id = Interlocked.Increment(ref _requestId),
                command,
                args = args ?? new { },
            });
            await _process.StandardInput.WriteLineAsync(request);
            await _process.StandardInput.FlushAsync();

            var line = await _process.StandardOutput.ReadLineAsync();
            if (string.IsNullOrWhiteSpace(line))
            {
                var error = await _process.StandardError.ReadToEndAsync();
                throw new InvalidOperationException(string.IsNullOrWhiteSpace(error)
                    ? "KaiCut 项目服务未返回结果。"
                    : error.Trim());
            }

            var response = JsonSerializer.Deserialize<BridgeResponse>(line,
                new JsonSerializerOptions(JsonSerializerDefaults.Web)
                {
                    PropertyNameCaseInsensitive = true,
                }) ?? throw new InvalidOperationException("KaiCut 项目服务返回了无效响应。");
            if (!response.Ok)
                throw new InvalidOperationException(response.Error ?? "项目操作未完成。");

            Session = response.Session ?? throw new InvalidOperationException("项目服务响应缺少项目状态。");
            return Session;
        }
        finally
        {
            _gate.Release();
        }
    }

    public async ValueTask DisposeAsync()
    {
        try
        {
            _process.StandardInput.Close();
            await _process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(2));
        }
        catch (TimeoutException)
        {
            if (!_process.HasExited) _process.Kill(entireProcessTree: true);
        }
        finally
        {
            _process.Dispose();
            _gate.Dispose();
        }
    }

    private sealed class BridgeResponse
    {
        public bool Ok { get; init; }
        public NativeProjectSession? Session { get; init; }
        public string? Error { get; init; }
    }
}
